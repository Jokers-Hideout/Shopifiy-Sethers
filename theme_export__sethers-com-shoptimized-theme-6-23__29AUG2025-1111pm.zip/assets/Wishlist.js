!function (i, t) {
    var s = t(".wishlist-btn"), e = t(".wishlist-tile-container"), a = e.length,
        l = localStorage.getItem("user_wishlist") || [];
    l.length > 0 && (l = JSON.parse(localStorage.getItem("user_wishlist")));
    var o = function () {
        window.location.href.indexOf("pages/wishlist") > -1 && (e.each(function () {
            var i = t(this).attr("data-product-id");
            -1 === l.indexOf(i) && (t(this).remove(), a--)
        }), t(".wishlist-loader").fadeOut(2e3, function () {
            t(".wishlist-grid").addClass("is_visible"), t(".wishlist-hero").addClass("is_visible"), 0 == a ? t(".wishlist-grid--empty-list").addClass("is_visible") : t(".wishlist-grid--empty-list").hide(), t(".wishlist-grid").fadeIn("slow")
        }))
    }, n = function () {
        s.on("mouseleave", function (i) {
            i.stopPropagation(), t(this).next(".tooltip").remove(), setTimeout(() => {
                t("#fake_input").blur()
            }, 10)
        }), s.click(function (i) {
            var s;
            i.preventDefault(), function (i) {
                var s = t(i).attr("data-product-id");
                if (t(i).hasClass("is-active")) {
                    var e = l.indexOf(s);
                    l.splice(e, 1), localStorage.setItem("user_wishlist", JSON.stringify(l))
                } else l.push(s), localStorage.setItem("user_wishlist", JSON.stringify(l));
                console.log(JSON.stringify(l))
            }(this), t(s = this).toggleClass("is-active"), t(".wishlistview").toggleClass("is-active"), t(".action--wishlist").hasClass("is-active") ? (t(".action--wishlist span").html('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 19.15 16.927"><path d="M13.67 0a4.85 4.85 0 0 0-4.1 2.23A4.86 4.86 0 0 0 5.47 0 5.53 5.53 0 0 0 0 5.67c0 2.42 1.2 4.8 3.53 7.1a24.9 24.9 0 0 0 5.82 4.1.5.5 0 0 0 .46 0 24.94 24.94 0 0 0 5.82-4.1c2.34-2.3 3.53-4.68 3.53-7.1A5.53 5.53 0 0 0 13.67 0z"/></svg>'), t(".action--wishlist").attr("data-original-title", "Remove from Wishlist"), t(s).next(".tooltip").find(".tooltip-inner").text("Added to Wishlist")) : (t(".action--wishlist span").html('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 19.15 16.927" style="&#10;    color: red;&#10;    fill: currentColor;&#10;"><path d="M13.67 0a4.85 4.85 0 0 0-4.1 2.23A4.86 4.86 0 0 0 5.47 0 5.53 5.53 0 0 0 0 5.67c0 2.42 1.2 4.8 3.53 7.1a24.9 24.9 0 0 0 5.82 4.1.5.5 0 0 0 .46 0 24.94 24.94 0 0 0 5.82-4.1c2.34-2.3 3.53-4.68 3.53-7.1A5.53 5.53 0 0 0 13.67 0zm1.24 12.04a23.73 23.73 0 0 1-5.33 3.8 23.72 23.72 0 0 1-5.34-3.8C2.1 9.94 1 7.8 1 5.67A4.46 4.46 0 0 1 5.48 1c1.62 0 2.68.7 3.67 2.34a.5.5 0 0 0 .87 0C11 1.7 12.08 1 13.7 1a4.46 4.46 0 0 1 4.46 4.67c0 2.13-1.1 4.28-3.23 6.37z"/></svg>'), t(".action--wishlist").attr("data-original-title", "Add to Wishlist"), t(s).next(".tooltip").find(".tooltip-inner").text("Removed from Wishlist")), h(s)
        })
    }, h = function (i) {
        t(".wishlist_mobile").removeClass("wishlist_mobile--show");

        if (t(window).width() < 1025 && (t(i).hasClass("is-active"))) {
            t(".wishlist_mobile .wishlist_text").text("Added to wishlist");
        } else {
            t(".wishlist_mobile .wishlist_text").text("Removed from wishlist");
        }

        setTimeout(function () {
            t(".wishlist_mobile").addClass("wishlist_mobile--show");
        }, 50);
    };
    i.init = function () {
        n(), s.each(function () {
            var i = t(this).attr("data-product-id");
            l.indexOf(i) > -1 && (t(this).addClass("is-active"), t(".action--wishlist span").html('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 19.15 16.927"><path d="M13.67 0a4.85 4.85 0 0 0-4.1 2.23A4.86 4.86 0 0 0 5.47 0 5.53 5.53 0 0 0 0 5.67c0 2.42 1.2 4.8 3.53 7.1a24.9 24.9 0 0 0 5.82 4.1.5.5 0 0 0 .46 0 24.94 24.94 0 0 0 5.82-4.1c2.34-2.3 3.53-4.68 3.53-7.1A5.53 5.53 0 0 0 13.67 0z"/></svg>'), t(".action--wishlist").attr("data-original-title", "Remove from Wishlist"))
        }), o()
    }, t(".action--wishlist").click(function () {
        var i = t(this).attr("data-product-id");
        t(".wishlist-tile-container[data-product-id=" + i + "]").hide()
    })
}(window.Wishlist = window.Wishlist || {}, jQuery);
